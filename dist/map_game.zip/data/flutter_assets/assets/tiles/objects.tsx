<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="objects" tilewidth="32" tileheight="32" tilecount="4" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="1">
  <image width="32" height="32" source="../images/email.png"/>
 </tile>
 <tile id="2">
  <image width="32" height="32" source="../images/fish.png"/>
 </tile>
 <tile id="3">
  <image width="32" height="32" source="../images/lava.jpeg"/>
 </tile>
 <tile id="4">
  <image width="32" height="32" source="../images/fish_fast.png"/>
 </tile>
</tileset>
