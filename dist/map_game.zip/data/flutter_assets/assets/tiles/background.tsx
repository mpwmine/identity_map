<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="background" tilewidth="32" tileheight="32" tilecount="483" columns="23">
 <image source="../images/background.png" width="736" height="672"/>
</tileset>
